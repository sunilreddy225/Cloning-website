Header
    Logo
    Search Bar
    Navigation 
    Sign in

Section 1
    Introduction

Section 2
    Products With Price Plan

Section 3
    Customer feedbacks

